const fs = require('fs');
const vm = require('vm');
const source = fs.readFileSync('/tmp/foxgen63/scripts/shared/flow.js','utf8');
const makeContext = (fetchImpl) => {
  const context = {
    window: {}, fetch: fetchImpl, AbortController, setTimeout, clearTimeout,
    TextEncoder, TextDecoder, crypto: require('crypto').webcrypto,
    atob: (s) => Buffer.from(s, 'base64').toString('binary'),
    btoa: (s) => Buffer.from(s, 'binary').toString('base64'),
    console,
  };
  vm.createContext(context);
  vm.runInContext(source, context);
  return context;
};
(async () => {
  const future = new Date(Date.now()+86400000).toISOString();
  const good = makeContext(async (_url, opts) => ({ok:true,status:200,json:async()=>({ok:true,valid:true,license_id:'lic-1',session_id:'lic-1',plan_days:15,expires_at:future,activated_at:new Date().toISOString()})}));
  const valid = await good.window.EUBackend.validateLicense('foxgen-abc-123',{deviceId:'stable-device'});
  if (!valid.valid || valid.license_id !== 'lic-1' || valid.key !== 'FOXGEN-ABC-123') throw new Error('valid normalization failed');
  const state = good.window.EUBackend.storageState(valid);
  if (!state.eu_license_valid || state.lovable_last_sync_status !== 'foxgen_verified' || state.lovable_last_sync_error !== '') throw new Error('state migration failed');
  const mismatch = makeContext(async()=>({ok:false,status:403,json:async()=>({ok:false,valid:false,status:'device_mismatch',reason:'device_mismatch',message:'This license is already active on another device.'})}));
  const denied = await mismatch.window.EUBackend.validateLicense('FOXGEN-ABC-123',{deviceId:'other-device'});
  if (denied.valid || denied.reason !== 'device_conflict' || !denied.message.includes('another device')) throw new Error('device mismatch mapping failed');
  let attempts=0;
  const retry = makeContext(async()=>{ attempts++; if(attempts===1) throw new Error('temporary'); return {ok:true,status:200,json:async()=>({ok:true,valid:true,license_id:'lic-2',plan_days:30,expires_at:future})}; });
  const recovered = await retry.window.EUBackend.validateLicense('FOXGEN-DEF-456',{deviceId:'stable-device'});
  if (!recovered.valid || attempts !== 2) throw new Error('retry failed');
  console.log('valid_activation PASS');
  console.log('stale_status_cleanup PASS');
  console.log('device_mismatch_mapping PASS');
  console.log('network_retry PASS');
})();
