/* FoxGEN Old Vibe — full page license gate.
   Blocks the Lovable page until a valid FoxGEN license key is activated. */
(function () {
  if (window.top !== window) return;
  if (window.__FOXGEN_GATE__) return;
  window.__FOXGEN_GATE__ = true;

  var HOST_ID = "foxgen-license-gate-host";
  var host = null;
  var root = null;

  function css() {
    return [
      ":host{all:initial}",
      ".wrap{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;",
      "background:radial-gradient(1200px 600px at 50% -10%,rgba(239,68,68,.18),transparent 60%),rgba(5,5,7,.94);",
      "backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);",
      "font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}",
      ".card{width:380px;max-width:92vw;padding:30px 26px;border-radius:18px;background:#0c0c0e;",
      "border:1px solid rgba(255,255,255,.10);box-shadow:0 30px 80px rgba(0,0,0,.7);text-align:center;color:#e2e2e4}",
      ".lock{font-size:38px;line-height:1;margin-bottom:12px}",
      ".t{font-size:17px;font-weight:800;margin:0 0 6px}",
      ".d{font-size:12px;color:rgba(255,255,255,.45);margin:0 0 18px}",
      "input{width:100%;padding:13px 14px;border-radius:11px;background:rgba(0,0,0,.5);",
      "border:1px solid rgba(255,255,255,.12);color:#fff;font-family:'JetBrains Mono',monospace;",
      "font-size:13px;letter-spacing:.06em;outline:none;text-transform:uppercase}",
      "input:focus{border-color:rgba(239,68,68,.55);box-shadow:0 0 0 3px rgba(239,68,68,.14)}",
      "button{width:100%;margin-top:12px;padding:13px 14px;border:0;border-radius:11px;cursor:pointer;",
      "background:#ef4444;color:#fff;font-weight:800;font-size:12px;letter-spacing:.08em;text-transform:uppercase}",
      "button:disabled{opacity:.6;cursor:default}",
      ".log{margin-top:12px;min-height:16px;font-family:'JetBrains Mono',monospace;font-size:11px;color:rgba(255,255,255,.5)}",
      ".ok{color:#10b981}.err{color:#ef4444}",
      ".ft{margin-top:16px;font-size:9px;letter-spacing:.24em;text-transform:uppercase;color:rgba(255,255,255,.22)}",
    ].join("");
  }

  function show() {
    if (host && document.documentElement.contains(host)) return;
    host = document.createElement("div");
    host.id = HOST_ID;
    root = host.attachShadow({ mode: "closed" });
    var style = document.createElement("style");
    style.textContent = css();
    var wrap = document.createElement("div");
    wrap.className = "wrap";
    wrap.innerHTML =
      '<div class="card">' +
      '<div class="lock">&#128274;</div>' +
      '<p class="t">Activate FoxGEN Old Vibe</p>' +
      '<p class="d">Enter your license key to unlock this page.</p>' +
      '<input id="k" placeholder="FOXGEN-XXX-XXX" spellcheck="false" autocomplete="off">' +
      '<button id="b">Activate License</button>' +
      '<div class="log" id="l"></div>' +
      '<div class="ft">FoxGEN Old Vibe</div>' +
      "</div>";
    root.appendChild(style);
    root.appendChild(wrap);
    (document.documentElement || document.body).appendChild(host);

    var input = root.getElementById("k");
    var btn = root.getElementById("b");
    var log = root.getElementById("l");
    try { document.documentElement.style.setProperty("overflow", "hidden", "important"); } catch (e) {}
    setTimeout(function () { try { input.focus(); } catch (e) {} }, 120);

    function setLog(text, cls) {
      log.textContent = text;
      log.className = "log " + (cls || "");
    }

    function activate() {
      var key = String(input.value || "").trim().toUpperCase();
      if (!key) { setLog("\u26a0 Enter a license key", "err"); return; }
      btn.disabled = true;
      setLog("\u23f3 Validating...", "");
      try { chrome.runtime.sendMessage({ action: "ping" }, function () { void chrome.runtime.lastError; }); } catch (e) {}
      chrome.runtime.sendMessage({ action: "pkActivate", licenseKey: key }, function (res) {
        if (chrome.runtime.lastError || !res) {
          btn.disabled = false;
          setLog("\u2717 Connection error", "err");
          return;
        }
        if (res.ok) {
          setLog("\u2713 License valid \u2014 unlocking...", "ok");
          try { chrome.storage.local.set({ ql_license_valid: true, ql_license_key: key, ql_native_chat: true }); } catch (e) {}
          setTimeout(function () { location.reload(); }, 700);
        } else {
          btn.disabled = false;
          var r = res.reason || "";
          var msg =
            r === "license_expired" ? "\u2717 License expired"
            : r === "license_revoked" ? "\u2717 License blocked"
            : r === "network" ? "\u2717 Connection error"
            : "\u2717 Invalid license key";
          setLog(msg, "err");
        }
      });
    }

    btn.addEventListener("click", activate);
    input.addEventListener("keydown", function (e) { if (e.key === "Enter") activate(); });
  }

  function hide() {
    try { if (host && host.parentNode) host.parentNode.removeChild(host); } catch (e) {}
    host = null;
    try { document.documentElement.style.removeProperty("overflow"); } catch (e) {}
  }

  function keepAlive() {
    // Re-inject if the page (or a bypass attempt) removes the overlay.
    setInterval(function () {
      chrome.storage.local.get(["ql_license_valid"], function (r) {
        if (r && r.ql_license_valid === true) return;
        if (!host || !document.documentElement.contains(host)) show();
      });
    }, 1000);
  }

  function check() {
    chrome.storage.local.get(["ql_license_valid", "ql_license_key"], function (r) {
      var valid = !!(r && r.ql_license_valid === true && r.ql_license_key);
      if (!valid) { show(); return; }
      hide();
      // Re-verify with the server on every page load; a blocked/expired key locks again.
      try {
        chrome.runtime.sendMessage({ action: "pkActivate", licenseKey: r.ql_license_key }, function (res) {
          if (chrome.runtime.lastError || !res) return; // offline: stay unlocked
          if (!res.ok && res.reason !== "network") {
            try { chrome.storage.local.set({ ql_license_valid: false }); } catch (e) {}
            show();
          }
        });
      } catch (e) {}
    });
  }

  try {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== "local" || !changes.ql_license_valid) return;
      if (changes.ql_license_valid.newValue === true) hide();
      else show();
    });
  } catch (e) {}

  check();
  keepAlive();
})();
