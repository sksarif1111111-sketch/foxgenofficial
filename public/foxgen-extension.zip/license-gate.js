/* FoxGEN Pro — full page license gate.
   Blurs and blocks the Lovable page until a valid FoxGEN license key is activated. */
(function () {
  if (window.top !== window) return;
  if (window.__FOXGEN_GATE__) return;
  window.__FOXGEN_GATE__ = true;

  var HOST_ID = "foxgen-license-gate-host";
  var host = null;
  var root = null;
  var LOGO = "";
  try { LOGO = chrome.runtime.getURL("icons/icon128.png"); } catch (e) {}

  function css() {
    return [
      ":host{all:initial}",
      "@keyframes fgIn{from{opacity:0;transform:translateY(14px) scale(.97)}to{opacity:1;transform:none}}",
      "@keyframes fgGlow{0%,100%{opacity:.55}50%{opacity:1}}",
      ".wrap{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;",
      "background:radial-gradient(900px 520px at 20% 0%,rgba(34,211,238,.20),transparent 60%),",
      "radial-gradient(900px 520px at 85% 100%,rgba(217,70,239,.22),transparent 60%),rgba(8,9,16,.72);",
      "backdrop-filter:blur(22px) saturate(140%);-webkit-backdrop-filter:blur(22px) saturate(140%);",
      "font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}",
      ".card{position:relative;width:390px;max-width:92vw;padding:34px 28px 26px;border-radius:24px;",
      "background:linear-gradient(160deg,rgba(24,26,44,.86),rgba(12,13,22,.92));",
      "border:1px solid rgba(255,255,255,.12);color:#e8ecf5;text-align:center;",
      "box-shadow:0 40px 110px rgba(0,0,0,.7),0 0 70px -30px rgba(34,211,238,.8);",
      "animation:fgIn .45s cubic-bezier(.22,1,.36,1);backdrop-filter:blur(8px)}",
      ".card:before{content:'';position:absolute;left:14%;right:14%;top:0;height:1px;",
      "background:linear-gradient(90deg,transparent,#22d3ee,#d946ef,transparent);animation:fgGlow 2.6s ease-in-out infinite}",
      ".logo{width:84px;height:84px;border-radius:22px;margin:0 auto 14px;display:block;",
      "box-shadow:0 0 50px -12px #22d3ee}",
      ".t{font-size:19px;font-weight:900;margin:0 0 6px;letter-spacing:.01em;",
      "background:linear-gradient(90deg,#22d3ee,#f4f6ff,#d946ef);-webkit-background-clip:text;background-clip:text;color:transparent}",
      ".d{font-size:12px;color:rgba(255,255,255,.48);margin:0 0 20px}",
      "input{width:100%;box-sizing:border-box;padding:14px 15px;border-radius:14px;background:rgba(0,0,0,.45);",
      "border:1px solid rgba(255,255,255,.14);color:#fff;font-family:'JetBrains Mono',monospace;",
      "font-size:13px;letter-spacing:.1em;outline:none;text-transform:uppercase;text-align:center}",
      "input:focus{border-color:rgba(34,211,238,.7);box-shadow:0 0 0 4px rgba(34,211,238,.14)}",
      "button{width:100%;margin-top:12px;padding:14px;border:0;border-radius:14px;cursor:pointer;",
      "background:linear-gradient(90deg,#22d3ee,#d946ef);color:#06070d;font-weight:900;font-size:12px;",
      "letter-spacing:.14em;text-transform:uppercase;transition:filter .15s}",
      "button:hover{filter:brightness(1.12)}",
      "button:disabled{opacity:.55;cursor:default}",
      ".log{margin-top:14px;min-height:16px;font-family:'JetBrains Mono',monospace;font-size:11px;color:rgba(255,255,255,.5)}",
      ".ok{color:#34d399}.err{color:#fb7185}",
      ".ft{margin-top:18px;font-size:9px;letter-spacing:.32em;text-transform:uppercase;color:rgba(255,255,255,.25)}",
    ].join("");
  }

  function show() {
    if (host && document.documentElement.contains(host)) return;
    host = document.createElement("div");
    host.id = HOST_ID;
    root = host.attachShadow({ mode: "closed" });
    var style = document.createElement("style");
    style.textContent = css();
    var wrap = document.createElement("div");
    wrap.className = "wrap";
    wrap.innerHTML =
      '<div class="card">' +
      (LOGO ? '<img class="logo" src="' + LOGO + '" alt="FoxGEN Pro">' : "") +
      '<p class="t">FoxGEN Pro</p>' +
      '<p class="d">Enter your license key to unlock this page.</p>' +
      '<input id="k" placeholder="FOXGEN-XXX-XXX" spellcheck="false" autocomplete="off">' +
      '<button id="b">Activate License</button>' +
      '<div class="log" id="l"></div>' +
      '<div class="ft">FoxGEN Pro</div>' +
      "</div>";
    root.appendChild(style);
    root.appendChild(wrap);
    (document.documentElement || document.body).appendChild(host);

    var input = root.getElementById("k");
    var btn = root.getElementById("b");
    var log = root.getElementById("l");
    try { document.documentElement.style.setProperty("overflow", "hidden", "important"); } catch (e) {}
    setTimeout(function () { try { input.focus(); } catch (e) {} }, 120);

    function setLog(text, cls) {
      log.textContent = text;
      log.className = "log " + (cls || "");
    }

    function activate() {
      var key = String(input.value || "").trim().toUpperCase();
      if (!key) { setLog("\u26a0 Enter a license key", "err"); return; }
      btn.disabled = true;
      setLog("\u23f3 Validating...", "");
      try { chrome.runtime.sendMessage({ action: "ping" }, function () { void chrome.runtime.lastError; }); } catch (e) {}
      chrome.runtime.sendMessage({ action: "pkActivate", licenseKey: key }, function (res) {
        if (chrome.runtime.lastError || !res) {
          btn.disabled = false;
          setLog("\u2717 Connection error", "err");
          return;
        }
        if (res.ok) {
          setLog("\u2713 License valid \u2014 unlocking...", "ok");
          try { chrome.storage.local.set({ ql_license_valid: true, ql_license_key: key, ql_native_chat: true }); } catch (e) {}
          setTimeout(function () { location.reload(); }, 700);
        } else {
          btn.disabled = false;
          var r = res.reason || "";
          var msg =
            r === "license_expired" ? "\u2717 License expired"
            : r === "license_revoked" ? "\u2717 License blocked"
            : r === "network" ? "\u2717 Connection error"
            : "\u2717 Invalid license key";
          setLog(msg, "err");
        }
      });
    }

    btn.addEventListener("click", activate);
    input.addEventListener("keydown", function (e) { if (e.key === "Enter") activate(); });
  }

  function hide() {
    try { if (host && host.parentNode) host.parentNode.removeChild(host); } catch (e) {}
    host = null;
    try { document.documentElement.style.removeProperty("overflow"); } catch (e) {}
  }

  function keepAlive() {
    // Re-inject if the page (or a bypass attempt) removes the overlay.
    setInterval(function () {
      chrome.storage.local.get(["ql_license_valid"], function (r) {
        if (r && r.ql_license_valid === true) return;
        if (!host || !document.documentElement.contains(host)) show();
      });
    }, 1000);
  }

  function verify(key) {
    try {
      chrome.runtime.sendMessage({ action: "pkActivate", licenseKey: key }, function (res) {
        if (chrome.runtime.lastError || !res) return; // offline: stay unlocked
        if (!res.ok && res.reason !== "network") {
          try { chrome.storage.local.set({ ql_license_valid: false }); } catch (e) {}
          show();
        }
      });
    } catch (e) {}
  }

  function check() {
    chrome.storage.local.get(["ql_license_valid", "ql_license_key"], function (r) {
      var valid = !!(r && r.ql_license_valid === true && r.ql_license_key);
      if (!valid) { show(); return; }
      hide();
      verify(r.ql_license_key);
      // Short/custom licenses expire fast — keep re-checking with the server.
      setInterval(function () {
        chrome.storage.local.get(["ql_license_valid", "ql_license_key"], function (s) {
          if (s && s.ql_license_valid === true && s.ql_license_key) verify(s.ql_license_key);
        });
      }, 15000);
    });
  }

  try {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== "local" || !changes.ql_license_valid) return;
      if (changes.ql_license_valid.newValue === true) hide();
      else show();
    });
  } catch (e) {}

  check();
  keepAlive();
})();
