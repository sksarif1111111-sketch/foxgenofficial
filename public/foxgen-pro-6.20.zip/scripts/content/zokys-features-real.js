/**
 * Feature runners — prefer FoxGEN Pro txt chat pipeline when available.
 */
(function () {
  "use strict";
  if (window.__zokysFeaturesRealV3__) return;
  window.__zokysFeaturesRealV3__ = true;

  var autoOn = false;
  try {
    chrome.storage.local.get(["zokys_auto_approve"], function (s) {
      autoOn = !!(s && s.zokys_auto_approve);
    });
    chrome.storage.onChanged.addListener(function (ch) {
      if (ch.zokys_auto_approve) autoOn = !!(ch.zokys_auto_approve.newValue);
    });
  } catch (_) {}

  function clickApproveButtons() {
    if (!autoOn) return;
    try {
      var btns = document.querySelectorAll("button, [role='button']");
      for (var i = 0; i < btns.length; i++) {
        var b = btns[i];
        if (b.closest && b.closest("#zokys-vx-root")) continue;
        var t = ((b.getAttribute("aria-label") || "") + " " + (b.textContent || "")).trim().toLowerCase();
        if (!t || t.length > 48) continue;
        if (
          /^(approve|allow|accept|confirm|continue|yes|apply|run|execute)$/i.test(t) ||
          /approve|allow changes|accept changes|confirm/i.test(t)
        ) {
          try { b.click(); } catch (_) {}
        }
      }
    } catch (_) {}
  }

  if (/\/projects\//i.test(location.pathname)) {
    setInterval(clickApproveButtons, 1800);
  }

  window.__zokysInjectPrompt = function (text) {
    if (typeof window.__zokysChatSendTxt === "function") {
      return window.__zokysChatSendTxt(text, { mode: "build", autoSend: true, showLoader: true });
    }
    return false;
  };
})();
